# Masukkan 4 angka yang ingin dijumlahkan
satu = int(input(">> Masukkan angka pertama: "))
dua = int(input(">> Masukkan angka kedua: "))
tiga = int(input(">> Masukkan angka ketiga: "))
empat = int(input(">> Masukkan angka keempat: "))

# Operasikan angka-angka tersebut
hasil = satu + dua + tiga + empat

# Cetak hasil penjumlahan
print("Hasil dari penjumlahan 4 angka yang kamu masukkan =", hasil)
