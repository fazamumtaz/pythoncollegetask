N = int(input())
if N % 2 == 1 :
    print(N)
else :
    print(N, "bukan bilangan bulat ganjil positif")

# N = float(input())
# if N % 2 == 1 and N - (N // 1) == 0 :
#     print(N)
# else :
#     print(N, "bukan bilangan positif")