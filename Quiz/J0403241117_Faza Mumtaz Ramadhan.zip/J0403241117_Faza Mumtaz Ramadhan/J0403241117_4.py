C = int(input())

if C < 0 :
    print("Dingin sekali")
elif C <= 20 :
    print("Dingin")
elif C <= 30 :
    print("Hangat")
else :
    print("Panas")